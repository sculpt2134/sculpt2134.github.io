const path = require('path'); // Node.js의 path 모듈 로드
const fs = require('fs'); // Node.js의 파일 시스템 모듈 로드
const HtmlWebpackPlugin = require('html-webpack-plugin'); // HtmlWebpackPlugin 모듈 로드
const { CleanWebpackPlugin } = require('clean-webpack-plugin'); // CleanWebpackPlugin 모듈 로드
const { execSync } = require('child_process'); // child_process 모듈의 execSync 메소드 로드
 
// 웹팩 설정 모듈 내보내기
module.exports = {
  mode: 'development', // 개발 모드 설정
  entry: './src/index.js', // 진입 파일 설정
  output: {
    path: path.resolve(__dirname, 'dist'), // 출력 디렉토리 설정
    filename: '[name]/[contenthash].html', // 출력 파일 이름 설정
  },
  module: {
    rules: [
      {
        test: /\.html$/, // HTML 파일을 대상으로 하는 로더 설정
        use: [
          {
            loader: 'html-loader', // HTML 로더 설정
            options: {
              minimize: false, // HTML 파일 최소화 여부 설정
            },
          },
        ],
      },
    ],
  },
  plugins: [
    new CleanWebpackPlugin(), // 빌드 전에 출력 디렉토리를 정리하는 플러그인 추가
    ...generateHtmlPlugins(), // HTMLWebpackPlugin을 생성하는 함수 실행
    // 빌드 후 inline_css_apply.js 파일 실행 설정
    {
      apply: (compiler) => {
        compiler.hooks.afterEmit.tap('AfterEmitPlugin', () => {
          try {
            execSync('node inline_css_apply.js', { stdio: 'inherit' }); // inline_css_apply.js 실행
            console.log('inline_css_apply.js 실행 성공.'); // 성공 메시지 출력
          } catch (error) {
            console.error('inline_css_apply.js 실행 중 에러:', error); // 에러 메시지 출력
          }
        });
      },
    },
  ],
};
 
// HTMLWebpackPlugin을 생성하는 함수 정의
function generateHtmlPlugins() {
  const pagesDir = path.resolve(__dirname, 'src/pages1'); // HTML 파일이 위치한 디렉토리 경로 설정
  const pages = fs.existsSync(pagesDir) ? fs.readdirSync(pagesDir) : []; // 디렉토리에 있는 파일 목록 가져오기
 
  const htmlPlugins = []; // HTMLWebpackPlugin 객체를 담을 배열 생성
 
  pages.forEach(page => {
    const pageName = path.basename(page, '.html'); // 파일 이름 추출
    ['genesis', 'hyundai', 'kia'].forEach(car => {
      const styleContent = fs.readFileSync(path.resolve(__dirname, `src/css/${car}.css`), 'utf8'); // 차량별 CSS 파일 내용 읽기
      let pageContent = fs.readFileSync(path.resolve(__dirname, `src/pages1/${page}`), 'utf8'); // HTML 파일 내용 읽기
 
      // HTML 파일에서 <link rel="stylesheet"> 태그 제거
      pageContent = pageContent.replace(/<link\s+rel="stylesheet"\s+.*?>/g, '');
 
      // <style> 태그를 인라인 스타일로 대체
      const modifiedPageContent = pageContent.replace('<style></style>', `<style>${styleContent}</style>`);
 
      // HTMLWebpackPlugin 객체 생성 후 배열에 추가
      htmlPlugins.push(
        new HtmlWebpackPlugin({
          templateContent: modifiedPageContent, // HTML 템플릿 내용 설정
          filename: `${car}/${pageName}.html`, // 출력 파일 경로 설정
          inject: false, // 자동 주입 비활성화
        })
      );
    });
  });
 
  return htmlPlugins; // HTMLWebpackPlugin 객체 배열 반환
}