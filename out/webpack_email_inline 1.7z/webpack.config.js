const path = require('path');
const fs = require('fs');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');
const { execSync } = require('child_process');

module.exports = {
  mode: 'development',
  entry: './src/index.js',
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name]/[contenthash].html',
  },
  module: {
    rules: [
      {
        test: /\.html$/,
        use: [
          {
            loader: 'html-loader',
            options: {
              minimize: false,
            },
          },
        ],
      },
    ],
  },
  plugins: [
    new CleanWebpackPlugin(),
    ...generateHtmlPlugins(),
    // Executing inline_css_apply.js after the build
    {
      apply: (compiler) => {
        compiler.hooks.afterEmit.tap('AfterEmitPlugin', () => {
          try {
            execSync('node inline_css_apply.js', { stdio: 'inherit' });
            console.log('inline_css_apply.js executed successfully.');
          } catch (error) {
            console.error('Error executing inline_css_apply.js:', error);
          }
        });
      },
    },
  ],
};

function generateHtmlPlugins() {
  const pagesDir = path.resolve(__dirname, 'src/pages1');
  const pages = fs.existsSync(pagesDir) ? fs.readdirSync(pagesDir) : [];

  const htmlPlugins = [];

  pages.forEach(page => {
    const pageName = path.basename(page, '.html');
    ['genesis', 'hyundai', 'kia'].forEach(car => {
      const styleContent = fs.readFileSync(path.resolve(__dirname, `src/css/${car}.css`), 'utf8');
      const pageContent = fs.readFileSync(path.resolve(__dirname, `src/pages1/${page}`), 'utf8');

      const modifiedPageContent = pageContent.replace('<style></style>', `<style>${styleContent}</style>`);

      htmlPlugins.push(
        new HtmlWebpackPlugin({
          templateContent: modifiedPageContent,
          filename: `${car}/${pageName}.html`,
          inject: false,
        })
      );
    });
  });

  return htmlPlugins;
}
