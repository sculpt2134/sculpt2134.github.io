
현재 폴더구조는 다음과 같아 .

project/
├── src/
│   ├── pages1/
│   │   ├── main.html
│   │   └── sub1.html
│   │   └──... (sub2, sub3, ..., sub10 등의 파일들)
│   │
│   ├── css/
│   │   ├── genesis.css
│   │   ├── hyundai.css
│   │   └── kia.css
│
└── webpack.config.js
└── index.html

빌드후에 아래처럼 만들고 싶다는 거야. css 파일과 js 파일은 필요가 없어. html 파일만 있으면 돼.

project/
├──dist/
│   ├── genesis/
│   │   ├── pages1/
│   │   │   ├── main.html
│   │   │   └── sub1.html
│   │   │   └──... (sub2, sub3, ..., sub10 등의 파일들)
│   │
│   ├── hyundai/
│   │   ├── pages1/
│   │   │   ├── main.html
│   │   │   └── sub1.html
│   │   │   └──... (sub2, sub3, ..., sub10 등의 파일들)
│   │
│   ├── kia/
│   │   ├── pages1/
│   │   │   ├── main.html
│   │   │   └── sub1.html
│   │   │   └──... (sub2, sub3, ..., sub10 등의 파일들)
│   
├── src/
│   ├── pages1/
│   │   ├── main.html
│   │   └── sub1.html
│   │   └──... (sub2, sub3, ..., sub10 등의 파일들)
│   │
│   ├── css/
│   │   ├── genesis.css
│   │   ├── hyundai.css
│   │   └── kia.css
│
└── webpack.config.js
└── index.html


  
1. 다음은 src/pages1/main.html 내용이야.

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>

</head>
<body>

    <style></style>
    main
</body>
</html>

1-1. 다음은 src/pages1/sub1.html 내용이야.

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>

</head>
<body>
<style></style>
    sub 이지롱
</body>
</html>

2. 다음은  css 파일의 내용이야

2-1. src/css/genesis.css 
em{color: #ff00ff;}

2-2. src/css/hyundai.css
em{color: #ff0000;}

2-3. src/css/kia.css
em{color: #000;}

3. 빌드시에 src/pages1/ 의 모든 파일을 읽고 그 파일 내용에  css 파일을 하나씩 적용해서 세개의 디렉토리에 개별로 저장해줘 위의 폴더구조를 참조해줘.
빌드 후의 html 의 내용을 예를 들면 아래 모습이야. 이것은 예시이고 빌드시엔 동적으로 이루어져야해

3-1. dist/genesis/main.html 파일이야. body 태그 안에 <style></style>태그 안으로 genesis.css 파일의 내용이 들어와야해.


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>

</head>
<body>

    <style>
        em{color: #ff00ff;}
    </style>
    main
</body>
</html>


3-2. dist/hyundai/main.html 파일이야. body 태그 안에 <style></style>태그 안으로 hyundai.css 파일의 내용이 들어와야해.


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>

</head>
<body>

    <style>
        em{color: #ff0000;}
    </style>
    main
</body>
</html>


3-3. dist/kia/main.html 파일이야. body 태그 안에 <style></style>태그 안으로 kia.css 파일의 내용이 들어와야해.


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Document</title>

</head>
<body>

    <style>
        em{color: #000;}
    </style>
    main
</body>
</html>

요약하면
src/pages1 디렉토리에  15개 html파일이 있고
src/css 디렉토리에 3개의 css 파일이 있어.
빌드시에 dist 폴더를 지우고 다시 만든다.
빌드시에 src/pages1 폴더의 모든 html 을 동적으로 내용을 읽어서
html 파일안의 style 태그 안으로 넣는다.
3개의 css 파일의 내용이 한개씩 개별로 들어가서 
3개의 폴더에 15개씩 총 45개의 html을 만든다.