const path = require('path');
const fs = require('fs');
const HtmlWebpackPlugin = require('html-webpack-plugin');
const { CleanWebpackPlugin } = require('clean-webpack-plugin');

module.exports = {
  mode: 'development',
  entry: './src/index.js', // 진입 파일로 변경
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name]/[contenthash].html',
  },
  module: {
    rules: [
      {
        test: /\.html$/,
        use: [
          {
            loader: 'html-loader',
            options: {
              minimize: false,
            },
          },
        ],
      },
    ],
  },
  plugins: [
    new CleanWebpackPlugin(), // dist 디렉토리를 빌드 전에 삭제
    ...generateHtmlPlugins(),
  ],
};

function generateHtmlPlugins() {
  // src/pages1 디렉토리에서 HTML 파일 목록을 가져옴
  const pagesDir = path.resolve(__dirname, 'src/pages1');
  const pages = fs.existsSync(pagesDir) ? fs.readdirSync(pagesDir) : [];

  const htmlPlugins = [];

  pages.forEach(page => {
    const pageName = path.basename(page, '.html');
    ['genesis', 'hyundai', 'kia'].forEach(car => {
      const styleContent = fs.readFileSync(path.resolve(__dirname, `src/css/${car}.css`), 'utf8');
      const pageContent = fs.readFileSync(path.resolve(__dirname, `src/pages1/${page}`), 'utf8');

      const modifiedPageContent = pageContent.replace('<style></style>', `<style>${styleContent}</style>`);

      htmlPlugins.push(
        new HtmlWebpackPlugin({
          templateContent: modifiedPageContent,
          filename: `${car}/${pageName}.html`,
          inject: false,
        })
      );
    });
  });

  return htmlPlugins;
}
