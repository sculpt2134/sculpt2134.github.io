const inlineCss = require('inline-css');
const fs = require('fs');
const path = require('path');

// dist 폴더 안의 모든 HTML 파일들에 대해 인라인 CSS 적용
applyInlineCssToDir('dist');

function applyInlineCssToDir(dirPath) {
    // 디렉토리 내의 모든 파일 및 하위 디렉토리 가져오기
    const files = fs.readdirSync(dirPath);

    files.forEach(file => {
        const filePath = path.join(dirPath, file);

        // 디렉토리인 경우 재귀적으로 호출하여 하위 디렉토리 탐색
        if (fs.statSync(filePath).isDirectory()) {
            applyInlineCssToDir(filePath);
        } else if (file.endsWith('.html')) {
            // HTML 파일인 경우 인라인 CSS 적용
            applyInlineCssToFile(filePath);
        }
    });
}

function applyInlineCssToFile(filePath) {
    const html = fs.readFileSync(filePath, 'utf-8');
    
    // 옵션 설정
    const options = {
        url: 'http://example.com', // 기본 URL 설정 (필요한 경우)
    };

    // inline-css 적용
    inlineCss(html, options)
        .then((inlinedHtml) => {
            // inline-css가 적용된 HTML 파일 저장
            fs.writeFileSync(filePath, inlinedHtml, 'utf-8');
            console.log(`Inline CSS applied successfully to ${filePath}!`);
        })
        .catch((err) => {
            console.error(`Error applying inline CSS to ${filePath}:`, err);
        });
}
